import os
import re
import markdown
import shutil
import json
from jinja2 import Environment, FileSystemLoader

# Configuration
INPUT_DIR_TALKS = r"E:\project\content\talks"
INPUT_DIR_BOOKS = r"E:\project\content\books"
INPUT_DIR_BIO = r"E:\project\content\bio"

OUTPUT_DIR = r"E:\project\website_output"
TEMPLATES_DIR = "templates"
IFRAMES_JSON = "dhamma_talks_iframes.json"


def setup_directories():
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        
    if os.path.exists("static"):
        shutil.copytree("static", os.path.join(OUTPUT_DIR, "static"), dirs_exist_ok=True)

def process_category(env, input_dir, output_subdir, list_filename, page_title, page_desc, iframes_data=None, is_bio=False):
    if not os.path.exists(input_dir):
        print(f"Warning: Directory not found: {input_dir}. Skipping {list_filename}.")
        return

    full_output_subdir = os.path.join(OUTPUT_DIR, output_subdir)
    os.makedirs(full_output_subdir, exist_ok=True)

    content_template = env.get_template('talk.html')
    list_template = env.get_template('list_page.html')

    category_items = []

    def natural_sort_key(s):
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', s)]

    # Separate directories and files inside the category directory
    all_items = sorted(os.listdir(input_dir), key=natural_sort_key)
    subdirs = [d for d in all_items if os.path.isdir(os.path.join(input_dir, d))]
    standalone_files = [f for f in all_items if f.endswith('.md')]

    # --- 1. PROCESS SUBDIRECTORIES (COLLECTIONS LIKE TALKS/BOOKS) ---
    for item_name in subdirs:
        item_path = os.path.join(input_dir, item_name)
        safe_collection_name = item_name.replace(' ', '_')
        collection_out_dir = os.path.join(full_output_subdir, safe_collection_name)
        os.makedirs(collection_out_dir, exist_ok=True)

        md_files = [f for f in os.listdir(item_path) if f.endswith('.md')]
        md_files = sorted(md_files, key=natural_sort_key)
        
        # Calculate depth for root_path relative to collection items
        depth = len([p for p in output_subdir.split('/') if p]) + 1
        item_root_path = "../" * depth

        collection_items_data = []
        for filename in md_files:
            name_without_ext = os.path.splitext(filename)[0]
            safe_filename = f"{name_without_ext.replace(' ', '_')}.html"

            match = re.search(r'(\d+)\s*$', name_without_ext) if is_bio else re.match(r'^\s*(\d+)', name_without_ext)
            item_number = match.group(1) if match else ""

            collection_items_data.append({
                'original_file': filename,
                'basename': filename,
                'title': name_without_ext,
                'output_file': safe_filename,
                'file_path_from_root': f"{output_subdir}/{safe_collection_name}/{safe_filename}",
                'number': item_number,
                'root_path': item_root_path
            })

        # Render markdown pages inside this collection
        for index, file_item in enumerate(collection_items_data):
            with open(os.path.join(item_path, file_item['original_file']), 'r', encoding='utf-8') as f:
                html_content = markdown.markdown(f.read(), extensions=['nl2br'])

            audio_iframe = iframes_data.get(file_item['basename']) if iframes_data else None

            rendered_item = content_template.render(
                title=file_item['title'],
                content=html_content,
                prev_talk=collection_items_data[index - 1] if index > 0 else None,
                next_talk=collection_items_data[index + 1] if index < len(collection_items_data) - 1 else None,
                audio_iframe=audio_iframe,
                parent_url=f"{output_subdir}/{safe_collection_name}/index.html", 
                parent_title=item_name,
                root_path=file_item['root_path']
            )

            with open(os.path.join(collection_out_dir, file_item['output_file']), 'w', encoding='utf-8') as f:
                f.write(rendered_item)

        # Generate the index page for this collection (Tier 2)
        rendered_collection_list = list_template.render(
            title=item_name,
            description=f"Contents of {item_name}",
            items=collection_items_data,
            root_path=item_root_path
        )
        with open(os.path.join(collection_out_dir, 'index.html'), 'w', encoding='utf-8') as f:
            f.write(rendered_collection_list)

        # Add the directory to the main category directory list
        category_items.append({
            'title': item_name,
            'file_path_from_root': f"{output_subdir}/{safe_collection_name}/index.html"
        })

    # --- 2. PROCESS STANDALONE FILES (FLAT STRUCTURE LIKE BIOGRAPHY) ---
    standalone_items_data = []
    depth = len([p for p in output_subdir.split('/') if p])
    item_root_path = "../" * depth

    # First pass: Gather metadata for all flat markdown files
    for item_name in standalone_files:
        name_without_ext = os.path.splitext(item_name)[0]
        safe_filename = f"{name_without_ext.replace(' ', '_')}.html"

        match = re.search(r'(\d+)\s*$', name_without_ext) if is_bio else re.match(r'^\s*(\d+)', name_without_ext)
        item_number = match.group(1) if match else ""

        standalone_items_data.append({
            'original_file': item_name,
            'basename': item_name,
            'title': name_without_ext,
            'output_file': safe_filename,
            'file_path_from_root': f"{output_subdir}/{safe_filename}",
            'number': item_number,
            'root_path': item_root_path
        })

    # Second pass: Render standalone items with functional sequential navigation
    for index, item_data in enumerate(standalone_items_data):
        input_path = os.path.join(input_dir, item_data['original_file'])
        with open(input_path, 'r', encoding='utf-8') as f:
            html_content = markdown.markdown(f.read(), extensions=['nl2br'])

        audio_iframe = iframes_data.get(item_data['original_file']) if iframes_data else None
        
        rendered_item = content_template.render(
            title=item_data['title'],
            content=html_content,
            prev_talk=standalone_items_data[index - 1] if index > 0 else None,
            next_talk=standalone_items_data[index + 1] if index < len(standalone_items_data) - 1 else None,
            audio_iframe=audio_iframe,
            parent_url=list_filename,
            parent_title=page_title,
            root_path=item_data['root_path']
        )

        with open(os.path.join(full_output_subdir, item_data['output_file']), 'w', encoding='utf-8') as f:
            f.write(rendered_item)
        
        # Add the file item directly to the category directory list
        category_items.append({
            'title': item_data['title'],
            'file_path_from_root': item_data['file_path_from_root']
        })

    # Generate the main category index page (Tier 1)
    rendered_main_list = list_template.render(
        title=page_title,
        description=page_desc,
        items=category_items,
        root_path=""
    )
    with open(os.path.join(OUTPUT_DIR, list_filename), 'w', encoding='utf-8') as f:
        f.write(rendered_main_list)

def build_site():
    setup_directories()
    env = Environment(loader=FileSystemLoader(TEMPLATES_DIR))
    
    iframes_data = {}
    if os.path.exists(IFRAMES_JSON):
        with open(IFRAMES_JSON, 'r', encoding='utf-8') as f:
            iframes_data = json.load(f)
    else:
        print(f"Warning: {IFRAMES_JSON} not found. Audio embeds will be skipped.")

    process_category(env, INPUT_DIR_TALKS, 'content/talks', 'talks.html', 'Dhamma Talks', 'An archive of recorded teachings of Ajaan Paññāvaḍḍho', iframes_data, is_bio=False)
    
    process_category(env, INPUT_DIR_BOOKS, 'content/books', 'writings.html', 'Dhamma Writings', 'An archive of published writings by Ajaan Paññāvaḍḍho', iframes_data, is_bio=False)
    
    process_category(env, INPUT_DIR_BIO, 'content/bio', 'biography.html', 'Biography', 'The Life of a Forest Monk', None, is_bio=True)

    static_pages = [
        {
            'output_file': 'index.html',
            'template_name': 'index.html',
            'title': 'Ajaan Paññāvaḍḍho Archive - Home'
        },
        {
            'output_file': 'about.html',
            'template_name': 'about.html',
            'title': 'About Ajaan Paññāvaḍḍho'
        },
        {
            'output_file': 'quotes.html',
            'template_name': 'generic_page.html',
            'title': 'Dhamma Quotes'
        },
        {
            'output_file': 'download.html',
            'template_name': 'download.html',
            'title': 'Downloads'
        }
    ]
    
    for page in static_pages:
        try:
            template = env.get_template(page['template_name'])
        except Exception:
            print(f"Template '{page['template_name']}' not found. Falling back to generic_page.html for {page['output_file']}")
            template = env.get_template('generic_page.html')
            
        rendered_page = template.render(title=page['title'], root_path="")
        with open(os.path.join(OUTPUT_DIR, page['output_file']), 'w', encoding='utf-8') as f:
            f.write(rendered_page)
            
    print(f"\nWebsite successfully built in: {OUTPUT_DIR}")

if __name__ == "__main__":
    build_site()